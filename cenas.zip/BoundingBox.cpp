#include "BoundingBox.h"


BoundingBox::BoundingBox() {
	_min = glm::vec3(0);
	_max = glm::vec3(0);
}

BoundingBox::~BoundingBox() {}

void BoundingBox::setMinMax(glm::vec3 min, glm::vec3 max) {
	_min = min;
	_max = max;
}

glm::vec3 BoundingBox::getMin() {
	return _min;
}

glm::vec3 BoundingBox::getMax() {
	return _max;
}

bool BoundingBox::isInside(glm::vec3 position) {
	if (position.x > _min.x && position.x < _max.x && position.y > _min.y && position.y < _max.y && position.z > _min.z && position.z < _max.z) return true;
	return false;
}

bool BoundingBox::rayIntersection(Ray * ray, glm::vec3 * intersection)
{
	glm::vec3 rayOrigin = ray->getOrigin();
	glm::vec3 rayDirection = ray->getDirection();


	return false;
}
