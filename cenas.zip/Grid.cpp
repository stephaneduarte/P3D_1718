#include "Grid.h"



Grid::Grid()
{
}

Grid::Grid(std::vector<Object*> objects) {
	//Create BB
	_bb = new BoundingBox();
	glm::vec3 min = glm::vec3(std::numeric_limits<float>::max());
	glm::vec3 max = glm::vec3(std::numeric_limits<float>::min());
	for (int i = 0; i < objects.size(); i++) {
		glm::vec3 object_min = objects[i]->getBoundingBox()->getMin();
		if (object_min.x < min.x) min.x = object_min.x - 0.0001f;
		if (object_min.y < min.y) min.y = object_min.y - 0.0001f;
		if (object_min.z < min.z) min.z = object_min.z - 0.0001f;
		glm::vec3 object_max = objects[i]->getBoundingBox()->getMax();
		if (object_max.x > max.x) max.x = object_max.x + 0.0001f;
		if (object_max.y > max.y) max.y = object_max.y + 0.0001f;
		if (object_max.z > max.z) max.z = object_max.z + 0.0001f;
	}
	_bb->setMinMax(min, max);

	//Dimensions of the grid
	glm::vec3 dim = max - min;
	
	float s = glm::pow((dim.x * dim.y * dim.z) / objects.size(), 1/3);
	
	int Nx = int(mFACTOR * dim.x / s) + 1;
	int Ny = int(mFACTOR * dim.y / s) + 1;
	int Nz = int(mFACTOR * dim.z / s) + 1;

	//Create cells
	for (int i = 0; i < (Nx * Ny * Nz); i++) {
		Cell * cell = new Cell();
		_cells.push_back(cell);
	}

	//Cells and Objects
	for (int i = 0; i < objects.size(); i++) {
		glm::vec3 objBBmin = objects[i]->getBoundingBox()->getMin();
		glm::vec3 objBBmax = objects[i]->getBoundingBox()->getMax();

		/* Compute indices of both cells that contain min and max coord of obj bbox */		int ixmin = glm::clamp((int)((objBBmin.x - _bb->getMin().x) * Nx / dim.x), 0, (Nx - 1));
		int iymin = glm::clamp((int)((objBBmin.y - _bb->getMin().y) * Ny / dim.y), 0, (Ny - 1));
		int izmin = glm::clamp((int)((objBBmin.z - _bb->getMin().z) * Nz / dim.z), 0, (Nz - 1));
		int ixmax = glm::clamp((int)((objBBmax.x - _bb->getMin().x) * Nx / dim.x), 0, (Nx - 1));
		int iymax = glm::clamp((int)((objBBmax.y - _bb->getMin().y) * Ny / dim.y), 0, (Ny - 1));
		int izmax = glm::clamp((int)((objBBmax.z - _bb->getMin().z) * Nz / dim.z), 0, (Nz - 1));

		/* insert obj to the overlaped cells */		for (int iz = izmin; iz < izmax; iz++) {
			for (int iy = iymin; iy < iymax; iy++) {
				for (int ix = ixmin; ix < ixmax; ix++) {
					_cells.at(ix + Nx * iy + Nx * Ny * iz)->addObject(objects.at(i));
				}
			}
		}
	}
}


Grid::~Grid()
{
}

bool Grid::rayIntersection(Ray* ray, glm::vec3 * intersectionPoint, glm::vec3 * normalIntersection, bool test) {
	//initialization
	glm::vec3 * origin = new glm::vec3(0);
	bool intersected = _bb->rayIntersection(ray, origin);
	return false;
}