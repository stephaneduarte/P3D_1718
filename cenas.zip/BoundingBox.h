#ifndef __BOUNDINGBOX__
#define __BOUNDINGBOX__

#include "glm/vec3.hpp"
#include "Ray.h"

class BoundingBox
{
private:
	glm::vec3 _min;
	glm::vec3 _max;

public:
	BoundingBox();
	virtual ~BoundingBox();

	void setMinMax(glm::vec3 min, glm::vec3 max);

	glm::vec3 getMin();
	glm::vec3 getMax();

	bool isInside(glm::vec3 position);
	bool rayIntersection(Ray * ray, glm::vec3 * intersection);
};

#endif
