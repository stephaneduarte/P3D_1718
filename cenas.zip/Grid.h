#ifndef __GRID__
#define __GRID__

#define mFACTOR 2 //Start with m=2

#include "Object.h"
#include "Cell.h"
#include <vector>

class Grid
{

private:
	BoundingBox * _bb = nullptr;
	std::vector<Cell*> _cells;

public:
	Grid();
	Grid(std::vector<Object*> objects);
	~Grid();

	bool rayIntersection(Ray* ray, glm::vec3 * intersectionPoint, glm::vec3 * normalIntersection, bool test);
};

#endif